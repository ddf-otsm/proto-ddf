"""NetSuite Integration Showcase - Multi-Source Data Integration

This is a generated app showcasing NetSuite integration capabilities.
"""

# Import the app from proto_ddf_app
from proto_ddf_app.proto_ddf_app import app, index

if __name__ == "__main__":
    app.compile()

