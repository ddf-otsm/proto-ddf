"""Integration tests for Proto-DDF workflows."""

