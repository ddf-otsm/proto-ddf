"""
Proto-DDF Test Suite
====================

Comprehensive test suite for Proto-DDF application generator.

Test Structure:
- unit/: Unit tests for individual components
- integration/: Integration tests for full workflows
"""

