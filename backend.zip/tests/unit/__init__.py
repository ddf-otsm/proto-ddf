"""Unit tests for Proto-DDF components."""

