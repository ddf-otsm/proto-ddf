"""Utility scripts for the project."""
