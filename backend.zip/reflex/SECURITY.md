# Security Policy

## Supported Versions

| Version  | Supported          |
| -------- | ------------------ |
| >= 0.7.0 | :white_check_mark: |

## Reporting a Vulnerability

Please report any security vulnerabilities to contact@reflex.dev
