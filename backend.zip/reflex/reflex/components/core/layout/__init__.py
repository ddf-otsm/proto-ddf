"""Core layout components."""
