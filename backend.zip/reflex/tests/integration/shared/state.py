"""Simple module which contains one reusable reflex state class."""

import reflex as rx


class SharedState(rx.State):
    """Shared state class for reflexers using libraries."""
