const test = "inside custom_script.js";
