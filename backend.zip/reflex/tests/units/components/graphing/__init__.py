"""Graphing component tests."""
