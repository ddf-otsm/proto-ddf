"""Datadisplay component tests."""
