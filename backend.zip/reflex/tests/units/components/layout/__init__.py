"""Layout component tests."""
